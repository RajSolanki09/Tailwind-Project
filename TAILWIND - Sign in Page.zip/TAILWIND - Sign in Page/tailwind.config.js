/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./DIST/Sign_in_page.html"],
  theme: {
    extend: {},
  },
  plugins: [],
}

