/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./DIST/index.html", "./DIST/product.html","./DIST/about.html","./DIST/shop.html","./DIST/blog.html","./DIST/contact_us.html"],
  theme: {
    extend: {},
  },
  plugins: [],
}

