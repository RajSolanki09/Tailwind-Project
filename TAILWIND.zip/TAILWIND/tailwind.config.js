/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./DIST/index.html"],
  theme: {
    extend: {},
  },
  plugins: [],
}

